$(document).ready(function(){ 
	if($(window).width() < 768) {
		$("#products_grid_before").removeClass("hidden-xs").addClass("collapse");
	}
});
