$(document).ready(function(){
	$('.grid').masonry({
	  // options...
	  itemSelector: '.l_blog_each',
	  columnWidth: 30
	});
})