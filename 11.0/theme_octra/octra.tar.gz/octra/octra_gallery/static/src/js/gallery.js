$(document).ready(function(){
	
	$('.gallery_desc_pop_up').click(function(){
		$('.gallery_des_pop_up_main').css('display','block');
	})
	
})
/*$(document).ready(function(){ 
	
	var $gallery = $('.gallery a').simpleLightbox();
	
			$gallery.on('show.simplelightbox', function(){
			 $(".sl-overlay").remove();
				$(".sl-wrapper").remove();
		})
	
});*/
