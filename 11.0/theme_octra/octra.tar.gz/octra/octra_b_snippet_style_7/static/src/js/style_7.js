/*$(document).ready(function() {
	
	 $(".ts7_s-lvl_heading").fadeTo("1000",1.0).css("transform","translate(0,1em)");
	 $(".ts7_f-lvl_heading").fadeTo("slow",1.0).css("transform","translate(0,2em)");
	 $(".ts7_sub_title").fadeTo("1000",1.0).css("transform","translate(0,3em)");
	 $(".ts7_btn_wrap").fadeTo("1000",1.0).css("transform","translate(0,3em)");
	 $(".ts7_hr").fadeTo("1000",1.0).css("transform","translate(0,1em)");
});*/
