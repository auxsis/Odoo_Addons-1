{
    # Theme information
    'name' : 'Octra Business CMS Blocks',
    'category' : 'Website',
    'version' : '1.0',
    'summary': '17 CMS Building Blocks',
    'description': """""",

    # Dependencies
    'depends': [
	    'octra_b_snippet_style_1',
        'octra_b_snippet_style_2',
        'octra_b_snippet_style_3',
        'octra_b_snippet_style_4',
        'octra_b_snippet_style_5',
        'octra_b_snippet_style_7',
        'octra_b_snippet_style_8',
        'octra_b_snippet_style_9',
        'octra_b_snippet_style_10',
        'octra_b_snippet_style_11',
        'octra_b_snippet_style_12',
        'octra_b_snippet_style_13',
        'octra_b_snippet_style_14',
        'octra_b_snippet_style_15',
        'octra_b_snippet_style_16',
        'octra_b_snippet_style_17',
        'octra_b_snippet_style_18',
        'octra_b_snippet_style_19',
        'octra_b_snippet_style_20',
        'octra_b_snippet_style_21',
	
    ],


    # Author
    'author': 'Emipro Technologies Pvt. Ltd.',
    'website': 'http://www.emiprotechnologies.com',

    # Technical
    'installable': True,
}

